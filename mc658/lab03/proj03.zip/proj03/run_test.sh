#!/bin/bash
./tsp_p.e -c -g -i in/gr_teste   -o out/gr_test.CONSTR_HEUR.out
read -p 'Press ENTER key...'

